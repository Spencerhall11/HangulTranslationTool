#include <windows.h>
#include <d3d11.h>
#include <dxgi1_2.h>
#include <iostream>

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "dxgi.lib")


//global config
const char* SHM_NAME = "Local\\HangulCaptureBuffer"; 
const int WIDTH = 1920;
const int HEIGHT = 1080;
//4 bytes per pixel 
const int CHANNELS = 4; 
const size_t BUFFER_SIZE = WIDTH * HEIGHT * CHANNELS;

int main() {
    //state that it is starting
    std::cout << "Starting Screen Capture Engine\n";

    //windows shared memory allocation
    HANDLE hMapFile = CreateFileMappingA(
        //use system memory
        INVALID_HANDLE_VALUE,
        NULL,
        PAGE_READWRITE,
        0,
        BUFFER_SIZE,
        SHM_NAME
    );
    //if no hmap file
    if(hMapFile == NULL){
        std::cerr << " Could not create shared memory " << GetLastError() << "\n";
        return 1;
    }
    //map the shared memory
    LPBYTE pBuf = (LPBYTE)MapViewOfFile(
        hMapFile,
        FILE_MAP_ALL_ACCESS,
        0,
        0,
        BUFFER_SIZE
    );
    //if buffer is null
    if (pBuf == NULL) {
        std::cerr << "Could not map shared memory: " << GetLastError() << "\n";
        CloseHandle(hMapFile);
        return 1;
    }
    //initialize DX11 Env
    ID3D11Device* d3d11Device = nullptr;
    ID3D11DeviceContext* d3d11Context = nullptr;
    D3D_FEATURE_LEVEL featureLevel;
    //make the DX11 device
    HRESULT hr = D3D11CreateDevice(
        // Default hardware adapter
        nullptr,                  
        // Enforce hardware acceleration execution
        D3D_DRIVER_TYPE_HARDWARE,
        // No software rasterizer module    
        nullptr,                      
        // Required compatibility flag for DXGI interaction
        D3D11_CREATE_DEVICE_BGRA_SUPPORT,
        // Use highest available feature level array
        nullptr,                      
        // Feature level array size
        0,                            
         // Default SDK version tracking
        D3D11_SDK_VERSION,           
        // Output device interface pointer
        &d3d11Device,                 
        // Output matched feature level
        &featureLevel,                
        // Output device context interface pointer
        &d3d11Context                 
    );
    //cannot create DX11
    if (FAILED(hr)) {
        std::cerr << "Failed to create DX11 Device.\n";
        UnmapViewOfFile(pBuf);
        CloseHandle(hMapFile);
        return 1;
    }

    //set up and bind DXGI duplication
    IDXGIDevice* dxgiDevice = nullptr;
    d3d11Device->QueryInterface(__uuidof(IDXGIDevice), (void**)&dxgiDevice);

    IDXGIAdapter* dxgiAdapter = nullptr;
    dxgiDevice->GetParent(__uuidof(IDXGIAdapter), (void**)&dxgiAdapter);
    dxgiDevice->Release();

    IDXGIOutput* dxgiOutput = nullptr;
    dxgiAdapter->EnumOutputs(0, &dxgiOutput); 
    dxgiAdapter->Release();

    IDXGIOutput1* dxgiOutput1 = nullptr;
    dxgiOutput->QueryInterface(__uuidof(IDXGIOutput1), (void**)&dxgiOutput1);
    dxgiOutput->Release();

    IDXGIOutputDuplication* deskDupl = nullptr;
    hr = dxgiOutput1->DuplicateOutput(d3d11Device, &deskDupl);
    dxgiOutput1->Release();

    //verify
    if (FAILED(hr)) {
        std::cerr << "DXGI Desktop Duplication setup failed.\n";
        d3d11Context->Release();
        d3d11Device->Release();
        UnmapViewOfFile(pBuf);
        CloseHandle(hMapFile);
        return 1;
    }

    std::cout << "Screen Capture Bound\n";  

    //frame capture and shm loop
    DXGI_OUTDUPL_FRAME_INFO frameInfo;
    IDXGIResource* desktopResource = nullptr;

    while (true) {
        hr = deskDupl->AcquireNextFrame(50, &frameInfo, &desktopResource);
        
        if (hr == DXGI_ERROR_WAIT_TIMEOUT) {
            continue; 
        }

        if (FAILED(hr)) {
            break; 
        }

        ID3D11Texture2D* acquireTex = nullptr;
        desktopResource->QueryInterface(__uuidof(ID3D11Texture2D), (void**)&acquireTex);
        desktopResource->Release();

        D3D11_TEXTURE2D_DESC desc;
        acquireTex->GetDesc(&desc);

        desc.Usage = D3D11_USAGE_STAGING;
        desc.BindFlags = 0;
        desc.CPUAccessFlags = D3D11_CPU_ACCESS_READ;
        desc.MiscFlags = 0;

        ID3D11Texture2D* stagingTex = nullptr;
        d3d11Device->CreateTexture2D(&desc, nullptr, &stagingTex);
        d3d11Context->CopyResource(stagingTex, acquireTex);

        D3D11_MAPPED_SUBRESOURCE mappedSubres;
        hr = d3d11Context->Map(stagingTex, 0, D3D11_MAP_READ, 0, &mappedSubres);
        
        if (SUCCEEDED(hr)) {
            BYTE* srcPtr = (BYTE*)mappedSubres.pData;
            BYTE* destPtr = pBuf;

            for (int y = 0; y < HEIGHT; ++y) {
                memcpy(destPtr, srcPtr, WIDTH * CHANNELS);
                srcPtr += mappedSubres.RowPitch; 
                destPtr += WIDTH * CHANNELS;
            }
            d3d11Context->Unmap(stagingTex, 0);
        }

        stagingTex->Release();
        acquireTex->Release();
        deskDupl->ReleaseFrame();

        Sleep(16); 
    }
    //resource clean up on close
    if (deskDupl) deskDupl->Release();
    if (d3d11Context) d3d11Context->Release();
    if (d3d11Device) d3d11Device->Release();
    UnmapViewOfFile(pBuf);
    CloseHandle(hMapFile);
    return 0;
}