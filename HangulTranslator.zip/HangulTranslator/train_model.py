import torch
from datasets import load_dataset
from transformers import (
    AutoTokenizer, 
    AutoModelForSeq2SeqLM, 
    DataCollatorForSeq2Seq, 
    Seq2SeqTrainingArguments, 
    Seq2SeqTrainer
)

#pull data from online database
print("Connecting to online database")
#load dataset of KR-EN translations
raw_dataset = load_dataset("strongminsu/ko-en-structured-translations")
#split into train and eval data
dataset_split = raw_dataset["train"].train_test_split(test_size=0.1)

#make architecture
model_checkpoint = "Helsinki-NLP/opus-mt-ko-en"
tokenizer = AutoTokenizer.from_pretrained(model_checkpoint)
model = AutoModelForSeq2SeqLM.from_pretrained(model_checkpoint)

#map base to token inputs
def preprocess_function(examples):
    # Adjust dictionary to match database schema
    inputs = examples["ko"]
    targets = examples["en"]
    

    model_inputs = tokenizer(inputs, max_length=128, truncation=True)
    labels = tokenizer(text_target=targets, max_length=128, truncation=True)
    
    model_inputs["labels"] = labels["input_ids"]
    return model_inputs

print("Tokenizing vocabulary for GPU training")
tokenized_datasets = dataset_split.map(preprocess_function, batched=True)

#training parameters
training_args = Seq2SeqTrainingArguments(
    output_dir="./training_checkpoints",
    eval_strategy="epoch",
    learning_rate=3e-5,
    per_device_train_batch_size=4, 
    weight_decay=0.01,
    save_total_limit=1,
    num_train_epochs=3,            
    fp16=torch.cuda.is_available(), 
    predict_with_generate=True
)

trainer = Seq2SeqTrainer(
    model=model,
    args=training_args,
    train_dataset=tokenized_datasets["train"],
    eval_dataset=tokenized_datasets["test"],
    data_collator=DataCollatorForSeq2Seq(tokenizer, model=model),
)

#run it
if __name__ == "__main__":
    print("Starting local model training ")
    trainer.train()

    #save the finished model
    trainer.save_model("./my_custom_korean_model")
    tokenizer.save_pretrained("./my_custom_korean_model")
    print("Training complete! Your custom offline model is ready at './my_custom_korean_model'")