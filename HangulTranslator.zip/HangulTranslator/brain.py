import easyocr
import numpy as np
import cv2
from multiprocessing import shared_memory
import re
from googletrans import Translator
import sys
import os
import subprocess
import time
import torch
from transformers import AutoTokenizer, AutoModelForSeq2SeqLM

def get_resource_path(relative_path):
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)
    
# the path of the eye
eye_exe = get_resource_path("translationEye.exe")

# activate the eye
eye_proc = subprocess.Popen([eye_exe], creationflags=0x08000000)
# announce wait for other processes
print("Waiting for eye before initializing shared memory")
time.sleep(2)

# target KR/EN for GPU OCR
print("Loading GPU accelerated array")
reader = easyocr.Reader(['ko','en'], gpu=True)

# load self trained model
print("loading offline trained model")
# select CUDA
device = "cuda" if torch.cuda.is_available() else "cpu"
# model path
model_path = "./my_custom_korean_model"

# if model isn't made
if not os.path.exists(model_path):
    # tell it isnt made and how to make it
    print(f"Custom model at {model_path} not found. Please execute python train_model to make the local model")
    # close to allow for model make
    sys.exit(1)

# tokenizer with the model
tokenizer = AutoTokenizer.from_pretrained(model_path)
# translation model
translation_model = AutoModelForSeq2SeqLM.from_pretrained(model_path).to(device)
# make translation cache
translation_cache = {}

# run the brain
def run_brain():
    # clear shared memory
    shm = None
    # try block
    try:
        # set shared memory
        shm = shared_memory.SharedMemory(name="Local\\HangulCaptureBuffer")
        # frame buffer
        frame_buffer = np.ndarray((1080, 1920, 4), dtype=np.uint8, buffer=shm.buf)
        # announce that it is live and how to close it
        print("Brain active, custom model active")
        print("Press ~ to close")

        # while loop for active
        while True:
            # convert DXGI to RGB
            img_rgb = cv2.cvtColor(frame_buffer, cv2.COLOR_BGRA2RGB)
            # OCR interface
            results = reader.readtext(img_rgb, detail=1, paragraph=True)
            # set up clean display
            display_frame = cv2.cvtColor(img_rgb, cv2.COLOR_RGB2BGR)

            for (bbox, text) in results:
                # target precise blocks
                if re.search(r'[\uac00-\ud7a3]', text):
                    
                    text_clean = text.strip()

                    # Corrected Indentation: Scoped within the validation block safely
                    if text_clean in translation_cache:
                        translated_text = translation_cache[text_clean]

                    else:
                        try:
                            # Run custom model token parsing and text inference pipelines
                            inputs = tokenizer(text_clean, return_tensors="pt", padding=True).to(device)
                            with torch.no_grad():
                                translated_tokens = translation_model.generate(**inputs)
                            
                            translated_text = tokenizer.decode(translated_tokens[0], skip_special_tokens=True)
                            translation_cache[text_clean] = translated_text
                        except Exception as translation_error:
                            translated_text = "[Inference Error]"

                    # Parse frame bounding box matrix tracking anchors
                    top_left = tuple(map(int, bbox[0]))
                    bottom_right = tuple(map(int, bbox[2]))
                    
                    # Draw translation overlay arrays directly onto the output viewport matrix
                    cv2.putText(display_frame, translated_text, (top_left[0], top_left[1] - 10), 
                                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 0, 128), 2)
                    cv2.rectangle(display_frame, top_left, bottom_right, (0, 255, 0), 1)

            # Downsample viewport display slightly to optimize processing loops
            cv2.imshow("Universal Brain View", cv2.resize(display_frame, (960, 540)))
            
            key = cv2.waitKey(1) & 0xFF

            # Handle Screenshot Capture key
            if key == ord('s'):
                if not os.path.exists("Screenshots"):
                    os.makedirs("Screenshots")
                timestamp = time.strftime("%Y%m%d-%H%M%S")
                filename = f"Screenshots/Custom_Translate_{timestamp}.png"
                cv2.imwrite(filename, display_frame)
                print(f"Captured: {filename}")

            # Safe exit matching key criteria
            if key == ord('~'):
                break              


    # exceptions
    except Exception as e:
        print(f"Error: {e}")
    # afterwards
    finally:
        if shm:
            # close shared memory
            shm.close()
        # close the windows
        cv2.destroyAllWindows()
        # close eye
        eye_proc.terminate()

# run it
if __name__ == "__main__":
    run_brain()