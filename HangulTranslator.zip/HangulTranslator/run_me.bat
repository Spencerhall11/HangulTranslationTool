@echo off
echo Initializing Korean Translator...
start "" "translationEye.exe"
timeout /t 2
python brain.py
pause